vim.g.blink_cmp = {
    fuzzy = {
        implementation = "lua", -- или "prefer_rust" — если хотите попробовать Rust снова
    },
}
require('options')
require('keymaps')
require('plugins')
require('colorscheme')
