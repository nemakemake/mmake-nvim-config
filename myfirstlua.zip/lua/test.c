#include "stdio.h"

int sum(int a, int b){
    return a + b;
}


void main(){
    int a;
    
    a = 12;

    int b = 1;

    printf(sum(a, b));
}
