import math 

print('a')

a = input()

input(a) 
b = math

